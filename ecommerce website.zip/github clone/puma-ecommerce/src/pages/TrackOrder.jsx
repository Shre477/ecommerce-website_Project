import React from 'react';
import AccountNav from '../components/AccountNav';

const TrackOrder = () => {
  return (
    <div className="account-page">
      <AccountNav />
      <div className="account-content">
        <h1>Track Order</h1>
        
        <div className="order-info-card">
          <h2>Order Information</h2> 
          <p>Order: Puma Classic Bag</p> 
          <p>Ordered: Nov 22</p> 
          <p>Tracking Number: 1245</p> 
          <p>Carrier: ExpressBus</p> 
          <p>Status: In Transit</p> 
        </div>

        <div className="tracking-timeline">
          <p className="step placed active">Placed</p> 
          <p className="step processed active">Processed</p>
          <p className="step shipped">Shipped</p>
          <p className="step delivered">Delivered</p>
        </div>
      </div>
    </div>
  );
};

export default TrackOrder;