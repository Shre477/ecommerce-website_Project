import React from 'react';
import AccountNav from '../components/AccountNav';

const OrderHistory = () => {
  return (
    <div className="account-page">
      <AccountNav />
      <div className="account-content">
        <h1>Order History</h1> 
        
        {/* New Order */}
        <div className="order-card new-order">
          <p>Puma Classic Bag Rs: 2999</p> 
          <p>Formal Canvas Shoe Rs: 3999</p> 
          <p className="status">Your order has been placed</p>
          <p className="delivery-date">Delivery expected by Nov 30</p>
          <button>Track Order</button>
        </div>

        {/* Delivered Order */}
        <div className="order-card delivered-order">
          <p>PUMA Formal Shoe</p> 
          <p>Rs: 1999</p> 
          <p>Size: 7</p> 
          <p className="status delivered">Your item has been delivered</p> 
          <p className="delivery-date">Delivered on Oct 20</p> 
        </div>
      </div>
    </div>
  );
};

export default OrderHistory;