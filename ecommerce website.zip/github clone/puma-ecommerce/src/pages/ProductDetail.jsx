// import React, { useState } from 'react';
// import { FaHeart, FaStar } from 'react-icons/fa';
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

// Component for a single color option
const ColorOption = ({ color, isSelected, onSelect }) => (
    <div
        className={`color-option ${isSelected ? 'selected' : ''}`}
        style={{ backgroundColor: color }}
        onClick={() => onSelect(color)}
        title={`Select ${color}`}
    ></div>
);

const ProductDetail = () => {
    // Dummy product data based on the image
    const product = {
        name: 'Classic Bag',
        brand: 'PUMA',
        price: 2999,
        rating: 4.0,
        ratingsCount: '6,234 ratings',
        reviewsCount: '584 reviews',
        colors: ['white', 'maroon', 'skyblue', 'purple'], // Using CSS color names for simplicity
        isNew: true,
    };

    const [selectedColor, setSelectedColor] = useState(product.colors[0]);

    // Function to render the star rating
    const renderStars = (rating) => {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 !== 0;
        const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        let stars = [];

        // Full Stars
        for (let i = 0; i < fullStars; i++) {
            stars.push(<span key={`full-${i}`} className="star full">★</span>);
        }
        // Half Star
        if (hasHalfStar) {
            stars.push(<span key="half" className="star half">★</span>); // Use a half star icon in real CSS
        }
        // Empty Stars
        for (let i = 0; i < emptyStars; i++) {
            stars.push(<span key={`empty-${i}`} className="star empty">☆</span>);
        }

        return stars;
    };

    return (
        <div className="product-detail-page">
            <div className="pdp-container">
                <div className="pdp-left-panel">
                    {product.isNew && <span className="pdp-new-tag">NEW</span>}
                    <div className="product-image-large">
                        {/* Image Placeholder: Brown Bag */}
                    </div>
                    {/* Heart/Wishlist Icon */}
                    <span className="pdp-wishlist-icon">❤️</span> 
                    
                    <p className="pdp-price">Rs. {product.price}</p>
                    <div className="pdp-actions">
                        <button className="pdp-buy-now-button">Buy Now</button>
                        <button className="pdp-add-to-cart-button">Add to Cart</button>
                    </div>
                </div>

                <div className="pdp-right-panel">
                    <p className="pdp-brand-name">{product.brand}</p>
                    <h1 className="pdp-product-name">{product.name}</h1>
                    
                    <div className="pdp-rating-section">
                        <span className="pdp-rating-number">{product.rating.toFixed(1)}</span>
                        <div className="pdp-stars">
                            {renderStars(product.rating)}
                        </div>
                        <p className="pdp-reviews-count">
                            ({product.ratingsCount} & {product.reviewsCount})
                        </p>
                    </div>

                    <div className="pdp-color-selection">
                        <h3 className="pdp-section-title">Colour</h3>
                        <div className="color-options-container">
                            {product.colors.map((color, index) => (
                                <ColorOption
                                    key={index}
                                    color={color}
                                    isSelected={color === selectedColor}
                                    onSelect={setSelectedColor}
                                />
                            ))}
                        </div>
                    </div>

                    {/* Additional sections (Size, Description, etc.) would go here */}
                </div>
            </div>
        </div>
    );
};



export default ProductDetail;