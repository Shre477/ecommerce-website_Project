import React from 'react';
import AccountNav from '../components/AccountNav';

const Profile = () => {
  return (
    <div className="account-page">
      <AccountNav />
      <div className="account-content">
        <h1>Profile & Security</h1>
        
        <div className="profile-section">
          <h2>Profile Information</h2> 
          <div className="profile-fields">
            <p>User Name: **Full Name**</p> 
            <p>Email: **User@example.com**</p>
            <p>Phone Number: **+91 ...**</p>
            <p>Gender: **Female**</p> 
            <button className="update-button">Update</button>
          </div>
        </div>

        <div className="security-section">
          <h2>Security Settings</h2>
          <p>Change Password</p> 
          <p>Login Activity</p> 
          <p>Recent Activity</p> 
        </div>
      </div>
    </div>
  );
};

export default Profile;