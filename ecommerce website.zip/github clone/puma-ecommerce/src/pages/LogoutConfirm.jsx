import React from 'react';
import AccountNav from '../components/AccountNav';
import { useNavigate } from 'react-router-dom';

const LogoutConfirm = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    // In a real application, you would clear user session/token here
    console.log('User logged out.');
    navigate('/'); // Redirect to home page after logout
  };

  return (
    <div className="account-page">
      <AccountNav />
      <div className="account-content">
        {/* This modal layout is based on PDF Page 12 */}
        <div className="logout-modal-overlay">
          <div className="logout-modal">
            <h2>Confirm Log Out</h2>
            <p>Are you sure you want to log out from this Account?</p>
            <div className="modal-actions">
              <button onClick={handleLogout} className="confirm-button">Log Out</button>
              <button onClick={() => navigate(-1)} className="cancel-button">Cancel</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LogoutConfirm;