import React, { useState } from 'react';
import { Link } from 'react-router-dom';
// Assuming AccountNav is imported for the sidebar structure

// --- 1. Sub-Component: Account Navigation Sidebar ---
// In a real app, this would be a separate reusable component (e.g., AccountNav.jsx)
const AccountSidebar = ({ activeLink }) => {
    const navLinks = [
        { name: 'Order History', path: '/account/order-history' },
        { name: 'Profile & Security', path: '/account/profile-security' },
        { name: 'Track Order', path: '/account/track-order' },
        { name: 'Favorites', path: '/account/favorites' },
        { name: 'Payment Method', path: '/account/payment-method' },
        { name: 'Log Out', path: '/logout-confirm' },
    ];
    
    // Function to check if the current link is active
    const isActive = (linkName) => linkName === activeLink;

    return (
        <div className="account-sidebar">
            <h3 className="sidebar-heading">Account Navigation</h3>
            <nav>
                <ul>
                    {navLinks.map((link) => (
                        <li key={link.name} className={isActive(link.name) ? 'active' : ''}>
                            <Link to={link.path}>{link.name}</Link>
                        </li>
                    ))}
                </ul>
            </nav>
        </div>
    );
};


// --- 2. Sub-Component: Favorite Product Card ---
const FavoritesCard = ({ product, onRemoveFavorite, onAddToCart }) => {
    // Helper function to render star ratings based on a hardcoded rating (e.g., 4 stars)
    const renderRating = (rating = 4) => {
        const stars = [];
        for (let i = 0; i < 5; i++) {
            stars.push(
                <span key={i} className={`star ${i < rating ? 'filled' : 'empty'}`}>
                    ★
                </span>
            );
        }
        return <div className="product-rating">{stars}</div>;
    };

    return (
        <div className="favorites-card">
            <div className="product-image">
                <img src={product.image} alt={product.name} />
                
                {/* Heart/Favorite Button */}
                <button 
                    className="favorite-toggle-btn active" // Always "active" since it's on the favorites page
                    onClick={() => onRemoveFavorite(product.id)}
                    title="Remove from favorites"
                >
                    ❤️
                </button>
            </div>
            
            <div className="product-info">
                <p className="product-name">{product.name}</p>
                {renderRating()}
                <p className="product-price">{product.price}</p>
            </div>
            
            <button 
                className="add-to-cart-button"
                onClick={() => onAddToCart(product)}
            >
                Add to Cart
            </button>
        </div>
    );
};


// --- 3. Main Component: Favorites Page ---
const Favorites = () => {
    // --- State for managing favorite products ---
    const [favoriteProducts, setFavoriteProducts] = useState([
        {
            name: "Puma Classic Grey", 
            price: "Rs. 2999", 
            id: 1,
            image: "https://tse1.mm.bing.net/th/id/OIP.mK86e5IKFb8QUgerx-OhuQHaE8?cb=ucfimg2&ucfimg=1&rs=1&pid=ImgDetMain&o=7&rm=31"
        },
        {
            name: "Formal Puma Black", 
            price: "Rs. 3999", 
            id: 2,
            image: "https://tse4.mm.bing.net/th/id/OIP.2h2IfBnr2ULt-2inKJqZ4AHaE8?cb=ucfimg2&ucfimg=1&rs=1&pid=ImgDetMain&o=7&rm=3"
        },
        {
            name: "Formal Canvas Shoe", 
            price: "Rs. 2999", // Adjusted price based on image
            id: 3,
            image: "https://t3.ftcdn.net/jpg/04/58/54/24/240_F_458542459_OIICpnAUUtwqClVT0MeKPLrC5pMM9wKT.jpg"
        },
        {
            name: "Forma Classic Bag", // Adjusted name based on image
            price: "Rs. 2999", 
            id: 4,
            image: "https://rukminim2.flixcart.com/image/480/640/xif0q/hand-messenger-bag/9/l/o/hand-bag178-11-2-exthb-178-handbag-exotic-8-5-original-imahc7m8ehchjh5m.jpeg?q=90"
        },
    ]);
    // ---------------------------------------------


    // Function to remove a product from the list
    const handleRemoveFavorite = (idToRemove) => {
        setFavoriteProducts(prevProducts => 
            prevProducts.filter(product => product.id !== idToRemove)
        );
        alert(`Product removed from favorites!`);
    };

    // Placeholder function for adding to cart (connect to CartContext in a real app)
    const handleAddToCart = (product) => {
        // In a real application, you would use useCart() hook here
        alert(`${product.name} added to the cart!`);
    };

    return (
        <div className="account-page">
            
            {/* The layout structure matches the image: Sidebar and Content */}
            <div className="account-layout"> 
                
                {/* Sidebar Component */}
                <AccountSidebar activeLink="Favorites" /> 
                
                <div className="account-content">
                    <h1>Favorites</h1> 
                    
                    {/* Check if the favorites list is empty */}
                    {favoriteProducts.length === 0 ? (
                        <p className="empty-favorites-message">
                            You don't have any favorites yet! Start browsing the shop.
                        </p>
                    ) : (
                        <div className="favorites-grid">
                            {favoriteProducts.map(product => (
                                <FavoritesCard 
                                    key={product.id}
                                    product={product}
                                    onRemoveFavorite={handleRemoveFavorite}
                                    onAddToCart={handleAddToCart}
                                />
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Favorites;