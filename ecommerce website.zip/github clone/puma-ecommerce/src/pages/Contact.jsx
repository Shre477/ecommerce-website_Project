import React from 'react';

const Contact = () => {
  return (
    <div className="contact-page">
      <h1>Contact Us</h1>
      <p>We are here to help with all your order, product and brand inquiries.</p>
      
      <div className="contact-options">
        <div className="contact-card">
          <div className="icon"></div>
          <h2>Customer Service</h2>
          <p>Monday thru Sunday | 8am - 8pm EST</p>
        </div>

        <div className="contact-card">
          <div className="icon"></div>
          <h2>Email Support</h2>
          <p>Send your detailed message any time.</p>
          <p>We aim to respond within 24 hours.</p>
        </div>
      </div>
    </div>
  );
};

export default Contact;