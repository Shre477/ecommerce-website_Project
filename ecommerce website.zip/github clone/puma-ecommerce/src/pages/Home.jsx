import React from 'react';
import { Link } from 'react-router-dom'; // 1. Import the Link component

const Home = () => {
    return (
        <div className="home-page">
            
            <div className="hero-banner">
                
                <h1 className="new-collection-text">NEW COLLECTION FOR SNEAKERS AND BAGS</h1>
                <p className="subtitle">PUMA - Where Sport Meets Style</p>
                
                {/* 2. Replace button with Link and add 'to' attribute */}
                <Link to="/shop" className="shop-now-button">
                    SHOP NOW
                </Link>
                
            </div>
            
            {/* You would add more content here based on other parts of a typical home page */}
        </div>
    );
};

export default Home;