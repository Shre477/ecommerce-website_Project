import React, { useState } from 'react'; // Ensure useState is imported
import { Link, useLocation } from 'react-router-dom'; 

// --- Sub-Component: Payment Method Card ---
const PaymentMethodCard = ({ icon, title, subtitle, isDefault, isCheckout, onSelect, isActive }) => (
    <div 
        className={`payment-card ${isActive ? 'default-card' : ''} ${isCheckout ? 'checkout-mode' : ''}`}
        // If in checkout mode, clicking selects the method
        onClick={() => isCheckout && onSelect(title)} 
    >
        <div className="payment-info">
            <div className="payment-icon">{icon}</div>
            <div className="payment-text">
                <p className="payment-title">{title}</p>
                <p className="payment-subtitle">{subtitle}</p>
            </div>
        </div>
        
        {/* Actions are only for Account Management */}
        {!isCheckout && (
            <div className="payment-actions">
                {isDefault && <span className="action-default">Default</span>}
                {!isDefault && <button className="action-button">Set Default</button>}
                <button className="action-button">Edit</button>
                <button className="action-button remove-button">Remove</button>
            </div>
        )}
        {/* Selection indicator for Checkout mode */}
        {isCheckout && (
             <div className="payment-selection-indicator">
                {/* Use a visual indicator for selection */}
                <span style={{ 
                    height: '16px', 
                    width: '16px', 
                    borderRadius: '50%', 
                    border: `2px solid ${isActive ? '#007bff' : '#ccc'}`,
                    backgroundColor: isActive ? '#007bff' : 'transparent',
                    display: 'inline-block'
                }}></span> 
             </div>
        )}
    </div>
);

// --- Sub-Component: Sidebar Navigation ---
const AccountSidebar = ({ activeLink }) => {
    // Note: Paths here must exactly match paths in App.jsx
    const navLinks = [
        { name: 'Order History', path: '/account/order-history' },
        { name: 'Profile & Security', path: '/account/profile-security' },
        { name: 'Track Order', path: '/account/track-order' },
        { name: 'Favorites', path: '/account/favorites' },
        { name: 'Payment Method', path: '/account/payment-method' },
        { name: 'Log Out', path: '/logout-confirm' },
    ];
    
    const isActive = (linkName) => linkName === activeLink;

    return (
        <div className="account-sidebar">
            <h3 className="sidebar-heading">Account Navigation</h3>
            <nav>
                <ul>
                    {navLinks.map((link) => (
                        <li key={link.name} className={isActive(link.name) ? 'active' : ''}>
                            {/* Use Link component for proper routing */}
                            <Link to={link.path}>{link.name}</Link>
                        </li>
                    ))}
                </ul>
            </nav>
        </div>
    );
};


// --- Main Component: Payment Method Page ---
const PaymentMethod = () => {
    const location = useLocation(); 
    
    // Check if the route is /payment (checkout flow)
    const isCheckout = location.pathname === '/payment'; 
    const isAccount = location.pathname === '/account/payment-method';
    
    // Use the first method as default selection
    const [selectedMethod, setSelectedMethod] = useState('Visa Card'); 
    
    // --- Sample Icons/Data ---
    const visaIcon = <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/1200px-Visa_Inc._logo.svg.png" alt="Visa Icon" style={{ width: '40px', height: 'auto' }} />;
    const mastercardIcon = <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" alt="Mastercard Icon" style={{ width: '40px', height: 'auto' }} />;
    const codIcon = <span style={{ fontSize: '2em', color: '#00cc66' }}>💵</span>;

    const paymentOptions = [
        { icon: visaIcon, title: "Visa Card", subtitle: "**** 1234 (Exp 12/26)", isDefault: true, id: 'visa' },
        { icon: mastercardIcon, title: "Mastercard", subtitle: "**** 5678 (Exp 08/25)", isDefault: false, id: 'mastercard' },
        { icon: codIcon, title: "Cash on Delivery", subtitle: "Pay by Cash/UPI on Delivery", isDefault: false, id: 'cod' },
    ];
    
    const handlePaymentFinalization = () => {
        // Here you would finalize the order and navigate to a confirmation page
        alert('Order Placed! Using: ${selectedMethod}. Navigating to confirmation...');
        // navigate('/order-confirmation'); 
    };

    return (
        <div className="payment-page-container">
            {/* The outer div should be the account page container if it's an account page */}
            <div className={`account-page ${isCheckout ? 'checkout-only' : ''}`}>
                
                <div className="account-layout">
                    {/* Only show sidebar if we are in the account management view */}
                    {isAccount && <AccountSidebar activeLink="Payment Method" />} 
                    
                    <div className="account-content">
                        <h2 className="content-title">
                            {isCheckout ? 'Select Payment Method' : 'Manage Saved Payment Methods'}
                        </h2>
                        
                        <div className="payment-list">
                            {paymentOptions.map(option => (
                                <PaymentMethodCard
                                    key={option.id}
                                    icon={option.icon}
                                    title={option.title}
                                    subtitle={option.subtitle}
                                    isDefault={option.isDefault} // Static default for account view
                                    isActive={option.title === selectedMethod} // Dynamic selection for checkout view
                                    isCheckout={isCheckout}
                                    onSelect={setSelectedMethod}
                                />
                            ))}
                            
                            {/* Button to add a new card */}
                            {!isCheckout && (
                                <button className="add-new-card-btn" style={{marginTop: '20px'}}>+ Add New Payment Method</button>
                            )}
                        </div>
                        
                        {/* Checkout Action Button */}
                        {isCheckout && (
                            <div className="checkout-action-area" style={{marginTop: '40px', borderTop: '1px solid #eee', paddingTop: '20px'}}>
                                <p className="final-payment-info">
                                    Final payment method: *{selectedMethod}*.
                                </p>
                                <button 
                                    className="final-pay-button"
                                    onClick={handlePaymentFinalization}
                                    style={{ padding: '15px 30px', backgroundColor: '#e5002d', color: 'white', border: 'none', cursor: 'pointer', fontSize: '1.1em'}}
                                >
                                    Pay Now & Place Order
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PaymentMethod;