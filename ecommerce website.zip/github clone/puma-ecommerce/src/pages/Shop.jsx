import React from 'react';
import { Link } from 'react-router-dom';

// 1. UPDATED: ProductCard now expects 'imageUrl' and 'onAddToCart'
const FavoriteIcon = ({ isFavorite, onClick }) => (
    <span 
        className="favorite-icon-shop" 
        onClick={onClick}
        // Basic inline styles for visibility - use CSS classes for production
        style={{ cursor: 'pointer', position: 'absolute', top: '10px', right: '10px', fontSize: '20px' }}
    >
        {isFavorite ? '❤️' : '🤍'} 
    </span>
);
const ProductCard = ({ name, price, imageUrl, onAddToCart, type }) => (
  <div className="product-card">
    <div className="product-image">
      {/* 2. REPLACED: Placeholder text with an actual <img> tag */}
      {imageUrl ? (
        <img src={imageUrl} alt={name} style={{ width: '100%', height: 'auto' }} />
      ) : (
        // Fallback text if no URL is provided
        'Image Unavailable'
      )}
    </div>
    <p className="product-name">{name}</p>
    <p className="product-price">{price}</p>
    
    {/* Button performs an action, not navigation */}
    <button 
      className="add-to-cart-button"
      onClick={onAddToCart} 
    >
      Add to Cart
    </button>
  </div>
);

const Shop = () => {
  
  // Placeholder for add to cart logic
  const handleAddToCart = (productName) => {
    alert('${productName} added to the cart!');
  };

  return (
    <div className="shop-page">
      <h2>Find Your Perfect Pair</h2>
      <p>Browse our latest Sneakers and Bags</p>
      <div className="shop-layout">
        <div className="sidebar">
          <h3>Products</h3>
          <ul>
            <li>Sneakers</li>
            <li>Bags</li>
          </ul>
          <h3>Price Range</h3>
          <p>Rs700 - Rs10k</p>
          <h3>Size</h3>
          <div className="size-options">6 7 8 9 10</div>
          {/* Other filters like Colour, Category, Bags Types... */}
        </div>
        
        <div className="product-grid">
          <div className="sort-options">
            <span>Sort by:</span>
            <button>Popularity</button>
            <button>Price</button>
            <button>Newest</button>
          </div>

          {/* 3. UPDATED: ProductCard instances now use the 'imageUrl' prop */}
          <ProductCard
            name="Puma Classic Grey" 
            price="Rs. 2999"
            imageUrl="https://cdn.chandigarhfirst.com/wp-content/uploads/2022/02/66201166210_1.jpg" 
            onAddToCart={() => handleAddToCart("Puma Classic Grey")}
            type="shoe" 
          />
          <ProductCard 
            name="Formal canvas shoe" 
            price="Rs. 3999"
            imageUrl="https://images.bewakoof.com/image/content/2023/04/18140713/image-113-819x1024.png" 
            onAddToCart={() => handleAddToCart("Formal canvas shoe")}
            type="shoe" 
          />
          <ProductCard 
            name="Puma Classic shoe" 
            price="Rs. 2999"
            imageUrl="https://tse1.mm.bing.net/th/id/OIP.2h2IfBnr2ULt-2inKJqZ4AHaE8?pid=ImgDetMain" 
            onAddToCart={() => handleAddToCart("Puma Classic shoe")}
            type="shoe" 
          />
          <ProductCard 
            name="Formal Puma shoe" 
            price="Rs. 3999"
            imageUrl="https://tse4.mm.bing.net/th/id/OIP.2h2IfBnr2ULt-2inKJqZ4AHaE8?cb=ucfimg2&ucfimg=1&rs=1&pid=ImgDetMain&o=7&rm=3" 
            onAddToCart={() => handleAddToCart("Formal Puma shoe")}
            type="shoe" 
          />
        </div>
      </div>
    </div>
  );
};

export default Shop;