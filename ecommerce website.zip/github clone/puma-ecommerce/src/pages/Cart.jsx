import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // 1. Import useNavigate

// NOTE: This CartItem component uses local state for quantity,
// which is okay for this file, but in a fully connected app (using CartContext), 
// this component would be removed and replaced by the version from the previous example.

// --- Sub-Component: Cart Item Card ---
const CartItem = ({ product, initialQuantity }) => {
    const [quantity, setQuantity] = useState(initialQuantity);

    const handleQuantityChange = (type) => {
        if (type === 'increment') {
            setQuantity(prev => prev + 1);
        } else if (type === 'decrement' && quantity > 1) {
            setQuantity(prev => prev - 1);
        }
    };

    return (
        <div className="cart-item-card">
            {product.isNew && <span className="item-new-tag">New</span>}
            <div className="item-image-placeholder">
                {/* Placeholder image for {product.name} */}
            </div>
            <div className="item-details">
                <p className="item-brand">{product.brand}</p>
                <p className="item-name">{product.name}</p>
                <p className="item-price">Rs. {product.price}</p>
                <div className="item-rating-placeholder">
                    <span>★★★★☆</span> 
                </div>
            </div>
            <div className="item-quantity-control">
                <button 
                    className="quantity-btn decrement" 
                    onClick={() => handleQuantityChange('decrement')}
                    disabled={quantity <= 1}
                >
                    -
                </button>
                <span className="quantity-display">{quantity}</span>
                <button 
                    className="quantity-btn increment" 
                    onClick={() => handleQuantityChange('increment')}
                >
                    +
                </button>
            </div>
        </div>
    );
};

// --- Sub-Component: Price Details Summary ---
// 2. Accept a prop for navigation
const PriceDetails = ({ summary, onPlaceOrder }) => {
    return (
        <div className="price-details-box">
            <h3 className="details-header">PRICE DETAILS</h3>
            <div className="price-line">
                <span>Price</span>
                <span>Rs. {summary.price.toFixed(0)}</span>
            </div>
            <div className="price-line discount-line">
                <span>Discount</span>
                <span>-Rs. {summary.discount.toFixed(0)}</span>
            </div>
            <div className="price-line">
                <span>Platform Fee</span>
                <span>Rs. {summary.platformFee.toFixed(0)}</span>
            </div>
            <div className="price-line">
                <span>Handling Fee</span>
                <span>Rs. {summary.handlingFee.toFixed(0)}</span>
            </div>
            
            <div className="total-amount-section">
                <span>Total Amount</span>
                <span className="total-price">Rs. {summary.totalAmount.toFixed(0)}</span>
            </div>
            
            {/* 3. Attach the navigation function to the button's onClick */}
            <button 
                className="place-order-button"
                onClick={onPlaceOrder}
            >
                PLACE ORDER
            </button>
        </div>
    );
};


// --- Main Component: Cart Page ---
const Cart = () => {
    // 4. Initialize the useNavigate hook
    const navigate = useNavigate();

    // 5. Create the navigation handler
    const handlePlaceOrder = () => {
        // Navigate to the payment/checkout route
        // You should define a route like '/checkout' or '/payment' in your App.js/router setup
        navigate('/payment'); 
    };

    // Dummy Data based on the image
    const cartItemsData = [
        {
            id: 1,
            name: 'Classic Bag',
            brand: 'PUMA',
            price: 2999,
            isNew: true,
            initialQuantity: 1,
            color: 'brown'
        },
        {
            id: 2,
            name: 'Formal Canvas Shoe',
            brand: 'PUMA',
            price: 3999,
            isNew: true,
            initialQuantity: 1,
            color: 'white/blue'
        },
    ];

    const priceSummary = {
        price: 6998,
        discount: 599,
        platformFee: 10,
        handlingFee: 70,
        totalAmount: 5880
    };

    const deliveryAddress = {
        name: 'PARAMITA PAKHIRA',
        pin: '700074',
        line1: 'Dumdum, KOLKATA'
    };


    return (
        <div className="cart-page">
            <div className="top-header-placeholder">
                {/* PUMA - SHOE & SOLE Header goes here */}
            </div>

            <div className="cart-layout">
                <div className="cart-items-section">
                    <h2 className="cart-title">Your Cart & Details</h2>
                    
                    <div className="delivery-address">
                        <p className="address-header">Delivery to: <span>{deliveryAddress.name}, {deliveryAddress.pin}</span></p>
                        <p className="address-line">{deliveryAddress.line1}</p>
                    </div>

                    <div className="cart-items-list">
                        {cartItemsData.map(item => (
                            <CartItem
                                key={item.id}
                                product={item}
                                initialQuantity={item.initialQuantity}
                            />
                        ))}
                    </div>
                </div>

                <div className="cart-summary-section">
                    {/* 6. Pass the handler function as a prop */}
                    <PriceDetails 
                        summary={priceSummary} 
                        onPlaceOrder={handlePlaceOrder} 
                    />
                </div>
            </div>
        </div>
    );
};

export default Cart;