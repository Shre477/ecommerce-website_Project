import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Home from './pages/Home';
import Shop from './pages/Shop';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import Contact from './pages/Contact';
import OrderHistory from './pages/OrderHistory';
import Profile from './pages/Profile';
import TrackOrder from './pages/TrackOrder';
import Favorites from './pages/Favorites';
import PaymentMethod from './pages/PaymentMethod';
import LogoutConfirm from './pages/LogoutConfirm';
import './App.css'; // Add basic styling

function App() {
  return (
    <Router>
      
      <Header />
      <div className="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/products" element={<ProductDetail />} /> {/* Alias for shop page */}
          <Route path="/contact" element={<Contact />} />
          <Route path="/payment" element={<PaymentMethod />} />
          
          {/* Detailed Pages (Using a generic ID for routing to product detail) */}
          <Route path="/product/:id" element={<ProductDetail />} />
          
          {/* Account/Cart Pages */}
          <Route path="/cart" element={<Cart />} />
          <Route path="/account/order-history" element={<OrderHistory />} />
          <Route path="/account/profile-security" element={<Profile />} />
          <Route path="/account/track-order" element={<TrackOrder />} />
          <Route path="/account/favorites" element={<Favorites />} />
          <Route path="/account/payment-method" element={<PaymentMethod />} />
          <Route path="/logout-confirm" element={<LogoutConfirm />} />

          {/* Fallback route */}
          <Route path="*" element={<Home />} /> 
        </Routes>
      </div>
    </Router>
  );
}

export default App;