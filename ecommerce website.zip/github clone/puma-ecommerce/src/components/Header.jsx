import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <header className="header">
      <div className="logo">
        <Link to="/">PUMA - SHOE & SOLE</Link> 
      </div>
      <nav className="nav-links">
        <Link to="/">Home</Link>                                   
        <Link to="/shop">Shop</Link> 
        <Link to="/products">Products</Link> 
        <Link to="/cart">Cart</Link>
      <Link to="/account/profile-security">Profile</Link>
      <Link to="/contact">Contact</Link>
      </nav>
      {/* Icons for search, cart, and profile could go here */}
      
     

    </header>
  );
};

export default Header;