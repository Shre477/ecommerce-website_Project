import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const AccountNav = () => {
  const location = useLocation();

  const navItems = [
    // Array elements must be separated by a comma (,)
    { name: 'Order History', path: '/account/order-history' },
    { name: 'Profile & Security', path: '/account/profile-security' },
    { name: 'Track Order', path: '/account/track-order' },
    { name: 'Favorites', path: '/account/favorites' },
    { name: 'Payment Method', path: '/account/payment-method' },
    { name: 'Log Out', path: '/logout-confirm' },
  ];

  return (
    <div className="account-nav">
      <h3>Account Navigation</h3>
      {navItems.map((item) => (
        <Link
          key={item.name}
          to={item.path}
          className={location.pathname === item.path ? 'nav-active' : ''}
        >
          {item.name}
        </Link>
      ))}
    </div>
  );
};

export default AccountNav;